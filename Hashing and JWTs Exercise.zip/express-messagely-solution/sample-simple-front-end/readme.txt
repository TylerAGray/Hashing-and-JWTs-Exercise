This is a demo sample front-end for messagely.

To start it:

    $ cd sample-simple-frontend
    $ python3 -m http.server 
